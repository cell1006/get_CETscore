﻿var dq={
	"rdsub":[{"code":"CET4","name":"全国大学英语四级考试(CET4)"},{"code":"CET6","name":"全国大学英语六级考试(CET6)"}]
};