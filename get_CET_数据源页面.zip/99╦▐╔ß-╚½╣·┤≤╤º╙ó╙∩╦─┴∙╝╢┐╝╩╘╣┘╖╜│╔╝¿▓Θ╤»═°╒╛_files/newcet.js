var testid = "";
var score = "";
var contenthtml = "";
var netschoolname = "";
var id_blank = "2016��12�±��Ի�11�¿���׼��֤��";
var name_blank = "������ǰ������";
var noname = false;
String.prototype.trim  =  function(){
   return  this.replace(/(^\s*)|(\s*$)/g,  "");
}
function gid(id) {
    return document.getElementById(id);
}
function gid_iframe(id) {
    var doc;
    if (document.all) {
        doc = document.frames[id].document;
    }
    else {
        doc = gid(id).contentDocument;
    }
    return doc;
}
function querystring(item){
    var svalue = location.search.match(new RegExp("[\?\&]" + item + "=([^\&]*)(\&?)","i"));
    return svalue ? svalue[1] : svalue;
}
function istestid(tid){
	var reg = /^[sf0-9]\d{14}$/;
    if (!reg.test(tid.toLowerCase())) 
        return false;
	
    if ((tid.substr(6, 3) != "162" && tid.substr(1, 3) != "163" && tid.substr(1, 3) != "164") || get_testtype(tid) == "")
        return false;
    return true;
}
function istestid_without_spoken(tid){
	var reg = /^\d{15}$/;
    if (!reg.test(tid)) 
        return false;
	if(tid.substr(6, 3) != "162")
		return false;
	return true;
}
function isspokentestid(tid){
	var reg = /^[sf]\d{14}$/;
    if (!reg.test(tid.toLowerCase())) 
        return false;
	return true;
}
function istestname(tname){
    var reg = /^[\u4e00-\u9fa5]{2}$/;
    if (!reg.test(tname)) 
        return false;
    return true;
}

function id_focus(con){
    if(con.value == id_blank){
        con.value = "";
        con.style.color = "#000";
    }
    con.style.border = "1px solid orange";
}
function id_blue(con){
    if(con.value == ""){
        con.value = id_blank;
        con.style.color = "#999";
    }
    con.style.border="1px solid #9a9a9a";
}
function id_write(con){
    var tid = con.value.trim();
    if(istestid(tid) && (isspokentestid(tid) || ifnoname(tid))){
        noname = true;
        gid("p_ifnoname").style.display = "none";
    }
    else{
        noname = false;
        gid("p_ifnoname").style.display = "";
    }
}
function name_focus(con){
    if(con.value == name_blank){
        con.value = "";
        con.style.color = "#000";
    }
    con.style.border = "1px solid orange";
}
function name_blue(con){
    if(con.value == ""){
        con.value = name_blank;
        con.style.color = "#999";
    }
    con.style.border="1px solid #9a9a9a";
}

function init(){
    testid = "";
    noname = false;
    score = getCookie("score");
    if (score != "") {
		showscore();
        delCookie("score");
    }
	onsearch(false);
}

function getscore() {

    var doc = gid_iframe("searchframe");
    score = doc.body.innerHTML;
    score = score.replace(/<.*?>/g, "");
    score = score.trim();
    if (score != "") {
        setCookie("score", score);
        location.href = location.href;
    }
	
}

function assertFormat(tid) {
	if (!istestid(tid)) {
        alert("׼��֤�Ÿ�ʽ����ȷ");
        return false;
    } 
    return true; 
}

function submit_search() {
   var testid_c = gid("id"); 
   var name_c = gid("name");
   var c = assertFormat(testid_c.value.trim());
   if(!c) {
       testid_c.focus();
       return;
   }
   
   testid = testid_c.value.trim();
   testid_c.value = testid.toUpperCase();
   
   var testname = "";
   if(!noname){
        if(!istestname(name_c.value.trim())){
            alert("��������������������");
            name_c.focus();
            return;
        }
        testname = name_c.value.trim();
   }
   
   name_c.value = testname;
   
   search();
}
function search(){
   if (contenthtml == "") {
       contenthtml = gid("content").innerHTML;
   }
   wait();
}
function wait() {
    var sec_before = 5;
    onsearch(true);
    wait_time(sec_before);
}
function wait_time(waitsec){
    if (waitsec > 0) {
        waitsec--;
        setTimeout("wait_time(" + waitsec + ")", 1000);
    }
    else {
        setCookie("id", testid);
		document.searchform.action = "/getscore" + testid;
        document.searchform.submit();
    }
}
function if_nowait(){
    if(score != ""){
        if(score.length == 1)
            return true;
    }
    return false;
}
function showscore() {

    var sarray=new Array();
	sarray = score.split(',');
	
	var score_success = false;
	if(sarray.length == 11){
		score_success = true;
	}
	
	var testid = "";
	var spoken_testid = "";
	var name = "";
    var school = "";
	var tlcj = false;
	
	if(score_success){
		testid = sarray[1];
		spoken_testid = sarray[9];
		name = sarray[7];
		school = sarray[6];
		if(parseInt(sarray[8]) == 1){
			tlcj = true;
		}
	}
	
    var resulthtml = "<div id='score_result'>";
	
	var scoretype = "Ӣ��������";
	if(score_success){
		scoretype = get_testtype(testid);
	}
	
	resulthtml += "<div style='font-size:16px;font-weight:bold;text-align:center;margin-top:10px;'>2016��12��ȫ����ѧ"+scoretype+"���Գɼ���ѯ���</div>";
    
	if (score_success) {
        resulthtml += "<div style='float:right;margin-right:20px;margin-top:-10px;'><a href='http://cet.99sushe.com/faq/#save' target='_blank' style='color:blue;'>����</a></div>";
    }
	
    resulthtml += "<div id='score_inner'>";
	
	resulthtml += "<ul>";
	if(name != "") resulthtml += "<li><div class='lileft1'>������</div><div class='liright1'>"+name+"</div></li>";
	if(school != "") resulthtml += "<li><div class='lileft1'>ѧУ��</div><div class='liright1'>" + school + "</div></li>";
	resulthtml += "</ul>";
	
	if(!score_success) {
		resulthtml += "<ul style='margin-top:100px;'>";
		var err = parseInt(score);
	    switch(err)
	    {
	        case 1:
			case 2:
	        {
	            resulthtml += "<li>�޷��ҵ���Ӧ�ķ���<br/><label style='font-weight:bold'>��ʹ����������</label></li>";
	            break;
	        }
	        default:
	        {
	            resulthtml += "<li>�޷��ҵ���Ӧ�ķ���<br/><label style='font-weight:bold'>��ȷ���������׼��֤�ż���������</label></li>";
	            break;
	        }
	    }
		resulthtml += "</ul>";
	}
	else {
			resulthtml += "<div class='score_title'>���Գɼ�</div>";
			resulthtml += "<ul class='score'>";
	        resulthtml += "<li><div class='lileft'>׼��֤�ţ�</div><div class='liright' style='font-weight:bold;'>" + testid + "</div></li>";
			resulthtml += "<li><div class='lileft'>�ܷ֣�</div><div class='liright' style='font-weight:bold;'>" + sarray[5] + "</div></li>";
	        resulthtml += "<li><div class='lileft'>������</div><div class='liright'>" + sarray[2] + "</div></li>";
	        resulthtml += "<li><div class='lileft'>�Ķ���</div><div class='liright'>" + sarray[3] + "</div></li>";
	        resulthtml += "<li><div class='lileft'>д���ͷ��룺</div><div class='liright'>" + sarray[4] + "</div></li>";
			resulthtml += "</ul>";
			
			if(tlcj){
				resulthtml += "<div class='tlcj'>�ÿ���Ϊ�����м�������Ϊ�⿼����������������ܷ֡�</div>";
			}
			
			resulthtml += "<div class='score_title'>���Գɼ�</div>";
			resulthtml += "<ul class='score'>";
			resulthtml += "<li><div class='lileft'>׼��֤�ţ�</div><div class='liright' style='font-weight:bold;'>" + spoken_testid + "</div></li>";
			resulthtml += "<li><div class='lileft'>�ȼ���</div><div class='liright'>" + sarray[10] + "</div></li>";
			resulthtml += "</ul>";
	}
	
	resulthtml +="</div>";
	
	resulthtml += "<div style='float:left;width:100px;padding-left:200px;'><input id='btn' type='button' value='����' onclick='research();' style='margin-top:-13px;' /></div>";
	resulthtml += "<div style='float:right;'><a href='http://cet.99sushe.com/faq/' target='_blank' style='color:blue;float:right;margin-right:5px;'>��ִ���</a></div>";
	resulthtml += "</div>";
	
    gid("content").innerHTML = resulthtml;
}
function onsearch(yes) {
    if (yes) {
        gid("content").style.display = "none";
        gid("root_wait").style.display = "";
    }
    else {
        gid("root_wait").style.display = "none";
        gid("content").style.display = "";
    }
}
function research() {
    location.href = location.href;
}

function get_testtype(tid) {
    if(istestid_without_spoken(tid)){
        switch (tid.substr(9, 1)) {
            case "1": return "Ӣ���ļ�";
            case "2": return "Ӣ������";
            case "3": return "�����ļ�";
            case "4": return "��������";
            case "5": return "�����ļ�";
            case "6": return "��������";
            case "7": return "�����ļ�";
            case "8": return "��������";
            case "9": return "�����ļ�";
            default: return "";
        }
    }
	else if(isspokentestid(tid)){
			if(tid.substr(1,3) == "161"){
				return "�����ļ�";
			}else{
				return "��������";
			}
		}
    return "";
}

function getCookie(name){ 
    name = name.trim();
    var strCookie=document.cookie; 
    var arrCookie=strCookie.split(";"); 
    for(var i=0;i<arrCookie.length;i++){ 
        var arr=arrCookie[i].split("="); 
        if(arr[0].trim() == name)
            return unescape(arr[1]);
    } 
    return ""; 
}

function setCookie(name,value){ 
    var cookieString = name+"="+escape(value);
    cookieString += ";path=/";
    document.cookie=cookieString;
}

function delCookie(name) {
    var cookieString = name + "=;path=/;expire=0";
    document.cookie = cookieString;
}
init();